import { resolve as _resolve, join } from 'path';

export const entry = './src/index.js';
export const output = {
  path: _resolve(__dirname, 'public'),
  filename: 'bundle.js'
};
export const module = {
  rules: [
    {
      test: /\.(js|jsx)$/,
      exclude: /node_modules/,
      use: {
        loader: 'babel-loader'
      }
    },
    {
      test: /\.css$/,
      use: ['style-loader', 'css-loader']
    }
  ]
};
export const resolve = {
  extensions: ['.js', '.jsx']
};
export const devServer = {
  static: join(__dirname, 'public'),
  compress: true,
  port: 9000
};
