import './styles.css';
import React, { useState, useEffect } from 'react';
import NoteForm from './NoteForm';
import NoteList from './NoteList';

const KEY = 'sticky-notes-app-notes';

function App() {
    const [notes, setNotes] = useState([]);

    
    useEffect(() => {
        const storedNotes = JSON.parse(localStorage.getItem(KEY)) || [];
        setNotes(storedNotes);
    }, []);

    
    useEffect(() => {
        localStorage.setItem(KEY, JSON.stringify(notes));
    }, [notes]);

    
    const addNote = (note) => {
        setNotes((prevNotes) => [...prevNotes, note]);
    };

    return (
        <div className="container">
            <h1>Sticky Notes</h1>
            <NoteForm addNote={addNote} />
            <NoteList notes={notes} setNotes={setNotes} />
        </div>
    );
}

export default App;
