import React from "react";
import NoteItem from "./NoteItem";

function NoteList({ notes, setNotes }) {
    const markAsCompleted = (id) => {
        setNotes(notes.map(note =>
            note.id === id ? { ...note, completed: !note.completed } : note
        ));
    };

    const deleteNote = (id) => {
        setNotes(notes.filter(note => note.id !== id));
    };

    return (
        <div className="note-list-container">
            <ul className="note-list">
                {notes.map(note => (
                    <NoteItem
                        key={note.id}
                        note={note}
                        markAsCompleted={markAsCompleted}
                        deleteNote={deleteNote}
                    />
                ))}
            </ul>
        </div>
    );
}

export default NoteList;
