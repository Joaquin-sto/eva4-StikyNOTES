import React from "react";

function NoteItem({ note, markAsCompleted, deleteNote }) {
    return (
        <li className={`note ${note.important ? 'important' : ''} ${note.completed ? 'completed' : ''}`}>
            <h5>{note.title}</h5>
            <p>{note.description}</p>
            <div className="note-footer">
                <button
                    onClick={() => markAsCompleted(note.id)}
                    className="btn complete"
                >
                    {note.completed ? 'Desmarcar' : 'Realizado'}
                </button>
                <button
                    onClick={() => deleteNote(note.id)}
                    className="btn delete"
                >
                    Eliminar
                </button>
            </div>
        </li>
    );
}

export default NoteItem;
