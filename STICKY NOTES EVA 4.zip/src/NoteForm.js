import React, { useState } from 'react';

function NoteForm({ addNote }) {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [important, setImportant] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        // Validación de campos requeridos
        if (!title.trim()) {
            setError('El título es requerido.');
            return;
        }
        if (!description.trim()) {
            setError('La descripción es requerida.');
            return;
        }

        setError('');

        const newNote = {
            id: new Date().getTime(),
            title,
            description,
            important
        };
        addNote(newNote);

        setTitle('');
        setDescription('');
        setImportant(false);
    };

    const toggleImportant = () => {
        setImportant(!important);
    };

    return (
        <form onSubmit={handleSubmit}>
            <div className="mb-3">
                <input
                    type="text"
                    className="form-control"
                    placeholder="Título"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                />
            </div>
            <div className="mb-3">
                <textarea
                    className="form-control"
                    placeholder="Descripción"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                />
            </div>
            <div className="important-container mb-3">
                <button
                    type="button"
                    className={`important-button btn ${important ? 'btn-danger' : 'btn-outline-danger'}`}
                    onClick={toggleImportant}
                >
                    {important ? 'Importante' : 'Marcar como Importante'}
                </button>
            </div>
            {error && <div className="alert alert-danger">{error}</div>}
            <button type="submit" className="btn btn-primary">Agregar Nota</button>
        </form>
    );
}

export default NoteForm;
